# Smart Practice - Telegram Mini App

Telegram Mini App для организации практики студентов. Приложение позволяет студентам находить вакансии, а компаниям - публиковать предложения о практике.

## 📋 Функциональность

### Для студентов:
- Регистрация с указанием направления подготовки и курса
- Добавление навыков и опыта работы
- Просмотр ленты вакансий с фильтрацией по направлению
- Подача заявок на практику
- Отслеживание статуса заявок

### Для партнеров (компаний):
- Создание профиля компании
- Публикация вакансий с указанием требований и вознаграждения
- Просмотр откликов студентов
- Запрос выгрузки данных студентов
- Приглашение сотрудников в компанию

### Для кураторов:
- Модерация вакансий перед публикацией
- Верификация навыков студентов
- Выгрузка данных студентов для партнеров

### Для администраторов:
- Полный контроль над пользователями и вакансиями
- Управление справочниками направлений подготовки

## 🛠 Технологии

- **Frontend:** React 18, styled-components, Telegram Web App SDK
- **Backend:** Node.js, Express, PostgreSQL
- **Bot:** node-telegram-bot-api
- **Deployment:** Docker, Docker Compose

## 🚀 Быстрый старт

### 1. Клонируйте репозиторий

```bash
cd smart-practice
```

### 2. Настройте переменные окружения

Отредактируйте файл `.env`:

```env
# Telegram Bot Configuration (получите у @BotFather)
BOT_TOKEN=your_bot_token_here
BOT_USERNAME=your_bot_username

# Application URLs (укажите ваш домен или IP)
WEB_APP_URL=https://your-domain.com
REACT_APP_API_URL=https://your-domain.com/api
REACT_APP_BOT_USERNAME=your_bot_username

# Admin Telegram ID (ID администратора)
ADMIN_TG_ID=123476570

# Database (будет использоваться в Docker)
DB_HOST=postgres
DB_PORT=5432
DB_NAME=smart_practice
DB_USER=postgres
DB_PASSWORD=postgres
```

### 3. Запустите приложение

```bash
docker-compose up -d
```

### 4. Настройте Telegram Bot

1. Откройте @BotFather в Telegram
2. Создайте нового бота или используйте существующего
3. Получите токен бота и вставьте его в `.env`
4. Установите webhook для бота:

```bash
curl -F "url=https://your-domain.com/bot<YOUR_BOT_TOKEN>" \
  https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook
```

### 5. Откройте приложение

- Веб-приложение: `https://your-domain.com`
- Bot URL: `https://t.me/your_bot_username`

## 🔧 Развертывание на сервере

### Требования

- Docker и Docker Compose
- Домен с SSL сертификатом (для продакшена)
- Минимум 1GB RAM

### Шаги развертывания

1. **Клонируйте проект**
```bash
git clone <repository-url>
cd smart-practice
```

2. **Настройте окружение**
```bash
cp .env.example .env
# Отредактируйте .env файл
nano .env
```

3. **Запустите контейнеры**
```bash
docker-compose up -d
```

4. **Проверьте статус**
```bash
docker-compose ps
docker-compose logs -f
```

5. **Настройте nginx (если используете отдельный сервер)**

Создайте конфигурацию `/etc/nginx/sites-available/smart-practice`:

```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        return 301 https://$server_name$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /api {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Настройка Telegram Bot

1. Создайте бота через @BotFather
2. Получите токен
3. Установите webhook:

```bash
curl -F "url=https://your-domain.com/bot<YOUR_BOT_TOKEN>" \
  https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook
```

4. Настройте меню бота:

```bash
curl -X POST \
  https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setMyCommands \
  -H 'Content-Type: application/json' \
  -d '{
    "commands": [
      {"command": "start", "description": "Начать работу"},
      {"command": "menu", "description": "Главное меню"}
    ]
  }'
```

## 📊 Структура базы данных

### Основные таблицы:

- **users** - пользователи (студенты, партнеры, кураторы, админы)
- **companies** - компании-партнеры
- **vacancies** - вакансии
- **applications** - заявки студентов
- **skills** - навыки студентов
- **majors** - направления подготовки
- **export_requests** - запросы на выгрузку данных

## 🔐 Роли пользователей

- **student** - студент, может просматривать вакансии и подавать заявки
- **partner** - представитель компании, может создавать вакансии
- **curator** - куратор, модерирует вакансии и верифицирует навыки
- **admin** - администратор, полный доступ

## 🎨 Настройка внешнего вида

Цветовая палитра и стили находятся в `/frontend/src/index.css`. 

Для изменения цветовой схемы отредактируйте CSS-переменные в начале файла.

## 📱 Использование

### Для студентов:

1. Нажмите /start в боте
2. Поделитесь контактом
3. Выберите роль "Студент"
4. Заполните профиль (ФИО, направление, курс)
5. Добавьте навыки
6. Просматривайте вакансии и подавайте заявки

### Для компаний:

1. Нажмите /start в боте
2. Поделитесь контактом
3. Выберите роль "Партнер"
4. Заполните профиль компании
5. Создавайте вакансии
6. Просматривайте отклики студентов

## 🛡 Безопасность

- Все данные передаются через HTTPS
- Используется аутентификация через Telegram
- Пароли не хранятся в открытом виде
- Реализована защита от SQL-инъекций

## 🐛 Решение проблем

### Бот не отвечает
1. Проверьте webhook: `docker-compose logs backend`
2. Убедитесь, что токен бота правильный
3. Проверьте доступность сервера

### Не загружаются вакансии
1. Проверьте логи backend: `docker-compose logs backend`
2. Убедитесь, что база данных инициализирована
3. Проверьте настройки CORS

## 📞 Поддержка

По всем вопросам обращайтесь к администратору системы.

## 📄 Лицензия

Проект создан для образовательных целей.